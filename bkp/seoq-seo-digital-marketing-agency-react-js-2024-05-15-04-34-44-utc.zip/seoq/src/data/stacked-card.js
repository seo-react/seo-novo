// Stacked Card One
export const StackedCardOneData = [
    {
        id: 1,
        image: "/assets/img/stack-card/1.png",
        heading: "Unleashing Unmatched Power with Seamless Simplicity",
        link: "/",
        link_text: "More Details",
    },
    {
        id: 2,
        image: "/assets/img/stack-card/2.png",
        heading: "Unparalleled Power, Effortless Mastery",
        link: "/",
        link_text: "More Details",
    },
    {
        id: 3,
        image: "/assets/img/stack-card/3.png",
        heading: "Insanely Powerfull. Easy to use",
        link: "/",
        link_text: "More Details",
    },
];