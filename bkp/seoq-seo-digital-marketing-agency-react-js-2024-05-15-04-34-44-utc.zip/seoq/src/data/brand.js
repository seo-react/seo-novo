// Brand One
export const BrandOneData = [
    {
        id: 1,
        image: "/assets/img/brand-two/polymath-black.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 2,
        image: "/assets/img/brand-two/epicurious-black.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 3,
        image: "/assets/img/brand-two/lightbox-black.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 4,
        image: "/assets/img/brand-two/quotient-black.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 5,
        image: "/assets/img/brand-two/boltshift-black.png",
        alt: "Brand",
        link: "#",
    },
];

// Brand Two
export const BrandTwoData = [
    {
        id: 1,
        image: "/assets/img/brand/polymath-white.png",
        alt: "brand logo",
        link: "#",
    },
    {
        id: 2,
        image: "/assets/img/brand/epicurious-white.png",
        alt: "brand logo",
        link: "#",
    },
    {
        id: 3,
        image: "/assets/img/brand/lightbox-white.png",
        alt: "brand logo",
        link: "#",
    },
    {
        id: 4,
        image: "/assets/img/brand/quotient-white.png",
        alt: "brand logo",
        link: "#",
    },
    {
        id: 5,
        image: "/assets/img/brand/boltshift-white.png",
        alt: "brand logo",
        link: "#",
    },
];