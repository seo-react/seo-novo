// Counter One
export const CounterOneData = [
    {
        id: 1,
        image: "/assets/img/funfact/1.svg",
        alt: "icon",
        countNumber: "4.2",
        countNumberLetter: "K",
        countNumberText: "Digital Global",
    },
    {
        id: 2,
        image: "/assets/img/funfact/2.svg",
        alt: "icon",
        countNumber: "25",
        countNumberLetter: "+",
        countNumberText: "Years Of Experience",
    },
    {
        id: 3,
        image: "/assets/img/funfact/3.svg",
        alt: "icon",
        countNumber: "3.7",
        countNumberLetter: "K",
        countNumberText: "Trusted Clients",
    },
    {
        id: 4,
        image: "/assets/img/funfact/4.svg",
        alt: "icon",
        countNumber: "254",
        countNumberLetter: "",
        countNumberText: "Team Members",
    },
    
];